package com.example.packagelabelreader;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.graphics.Rect;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer;
import com.google.firebase.ml.vision.text.RecognizedLanguage;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    Uri image_uri;

    private static final int PERMISSION_CODE = 1000;
    private static final int IMAGE_CAPTURE_CODE = 1001;

    TextView txtview;
    Button captureButton, detectTextButton;
    ImageView imgView;

    Button button;
    Button button2;

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static final int REQUEST_LOCATION_CODE = 1;

    String str = "";
    String address = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtview = findViewById(R.id.textView);
        captureButton = findViewById(R.id.capture_button);
        detectTextButton = findViewById(R.id.detect_text);
        imgView = findViewById(R.id.imageView);
        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);

        captureButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //if system os is >= marshmallow request runtime permission
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if(checkSelfPermission(Manifest.permission.CAMERA) ==
                            PackageManager.PERMISSION_DENIED ||
                            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                                    PackageManager.PERMISSION_DENIED){
                        // permission not enabled, request it
                        String[] permission = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        // show popup to request it
                        requestPermissions(permission, PERMISSION_CODE);

                    }else{
                        //permission already granted
                        openCamera();
                    }
                }else{
                    // system os < marshmallow

                    openCamera();
                }

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateTextView();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                func();
            }
        });

        detectTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runTextDetection();
            }
        });

    }

    private void openCamera() {

        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera");
        image_uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        // Camera intent
        Intent camera_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        camera_intent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        startActivityForResult(camera_intent, IMAGE_CAPTURE_CODE);


    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
//            Bundle extras = data.getExtras();
//            imageBitmap = (Bitmap) extras.get("data");
//            imageView.setImageBitmap(imageBitmap);
//        }

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            imgView.setImageURI(image_uri);

        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode){
            case PERMISSION_CODE: {
                if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    // permission was granted from popup
                    openCamera();;
                }else{
                    // 9: 16
                    Toast.makeText(this, "Permission denied...", Toast.LENGTH_SHORT).show();
                }
            }
            case REQUEST_LOCATION_CODE: {
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    //getLocation();
                }else
                {
                    Toast.makeText(this, "Permission denied...", Toast.LENGTH_SHORT).show();
                }
            }

        }
    }




    private void runTextDetection(){
        FirebaseVisionImage image = null;
        try {
            image = FirebaseVisionImage.fromFilePath(this, image_uri);
        } catch (IOException e) {
            e.printStackTrace();
        }

        FirebaseVisionTextRecognizer detector = FirebaseVision.getInstance()
                .getCloudTextRecognizer();


        Task<FirebaseVisionText> result =
                detector.processImage(image)
                        .addOnSuccessListener(new OnSuccessListener<FirebaseVisionText>() {
                            @Override
                            public void onSuccess(FirebaseVisionText firebaseVisionText) {
                                // Task completed successfully
                                // ...

                                txtview.setText("success");
                                extractText(firebaseVisionText);
                            }
                        })
                        .addOnFailureListener(
                                new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Task failed with an exception
                                        // ...
                                        txtview.setText("success'nt");
                                    }
                                });

    }

    private void extractText(FirebaseVisionText result){
        boolean gotFromAddress = false;
        String resultText = result.getText();
        txtview.setText("");
        str = "";


        for(int i = 0; i<  result.getTextBlocks().size(); i++){
            String blockText = result.getTextBlocks().get(i).getText();
            str = str + blockText + "\n\n" + "^";
        }
        str = str.toLowerCase();

        str = str.replaceAll(":", "");
        str = str.replaceAll("from", "");
        str = str.replaceAll("to", "");

        txtview.setText(str);


        Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocationName(str, 1);
        } catch (IOException e) {
            e.printStackTrace();
            txtview.setText("no results");
        }
        //address = addresses.get(0).getFeatureName() + "\n" + addresses.get(0).getPremises() + "\n" + addresses.get(0).getAddressLine(0);

        Address obj = addresses.get(0);
        address = obj.getAddressLine(0);

        String[] parts = address.split(" ");

        for(int i = 0; i< parts.length; i++){
            int index = str.indexOf(parts[i]);

            if( index != -1){

                for(int j = index-1; j>= 0; j--){
                    if(str.charAt(j) == '^'){
                        address = str.substring(j+1,index) + address ;
                        break;
                    }
                    if(j == 0){
                        address = str.substring(0,index) + address ;
                        break;
                    }
                }

                str = str.substring(index);
                break;
            }

        }

        for(int i = 0; i< address.length(); i++){
            if(address.charAt(i) == ' ' || address.charAt(i) == '\n' ){
                if(address.substring(i).equals("ship")){
                    address = address.substring(i);
                }
            }
        }

        txtview.setText(address + "\n" + "\n" + "\n" + "\n");
        address = address.toLowerCase();
        address = address.replaceAll(",", "");

    }

    private void updateTextView(){

        String[] parts = address.split(" ");

        for(int i = 0; i< parts.length; i++){
            int index = str.indexOf(parts[i]);

            if( index != -1){

                str = str.substring(index);
                break;
            }

        }


        for(int i = 0; i< parts.length; i++){
            str = str.replaceFirst(parts[i], "");
        }

        txtview.setText( address + "\n" + "\n" + "\n" + "\n" + str);

        func();

    }

    private void func(){
        Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
        List<Address> addresses = null;
        try {
            addresses = geocoder.getFromLocationName(str, 1);
        } catch (IOException e) {
            e.printStackTrace();
            txtview.setText("no results");
        }
        Address obj = addresses.get(0);
        address = obj.getAddressLine(0);

        String[] parts = address.split(" ");

        for(int i = 0; i< parts.length; i++){
            int index = str.indexOf(parts[i]);

            if( index != -1){

                for(int j = index-1; j>= 0; j--){
                    if(str.charAt(j) == '^'){
                        address = str.substring(j+1,index) + address ;
                        break;
                    }
                    if(j == 0){
                        address = str.substring(0,index) + address ;
                        break;
                    }
                }

                str = str.substring(index);
                break;
            }

        }

        for(int i = 0; i< address.length(); i++){
            if(address.charAt(i) == ' ' || address.charAt(i) == '\n' ){
                if(address.substring(i).equals("ship")){
                    address = address.substring(i);
                }
            }
        }

        txtview.setText( address + "\n" + "\n" + "\n" + "\n");
        address = address.toLowerCase();
        address = address.replaceAll(",", "");


    }




}